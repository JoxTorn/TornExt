Source code is odfuscated with online tool https://obfuscator.io/
All settings are on image obfuscator.io.png