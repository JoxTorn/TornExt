(function(){
    
//console.log('jail');


const jail = document.querySelector('.user-info-list-wrap');

if(jail){
    function createElement(tag){
        return document.createElement(tag);
    }

    function insertAfter(element, after){
        after.parentNode.insertBefore(element, after.nextSibling);
    }


    var container = document.querySelector('.content-title');

    var myDiv = document.createElement('div');
    myDiv.id = 'JoxDiv';

    insertAfter(myDiv, container);

    var widget = TornExtGlobal.Widget(
        {
            title:'Jail Filter',
            colapsable: true
        }
    )

    var filterTime = 0;
    var filterLvl = 0;
    var quick = false;

    myDiv.appendChild(widget.container);

    var formWrap = createElement('div');
    formWrap.classList.add('my-float-right');

    var txtmaxlvl = createElement('input');
    txtmaxlvl.id = 'maxlvl';
    txtmaxlvl.type = 'number';
    txtmaxlvl.min = 1;
    txtmaxlvl.max = 100;
    txtmaxlvl.classList.add('my-input-jail');
    txtmaxlvl.classList.add('my-margin-left10');
    txtmaxlvl.addEventListener('change', (e) => {
        filterLvl = e.target.value == 0 ? 0 : parseInt(e.target.value);
        saveJailConfig();
        filterJail();
    });
    var lblmaxlvl = createElement('label');
    lblmaxlvl.for = 'maxlvl';
    lblmaxlvl.classList.add('my-margin-left10');
    lblmaxlvl.classList.add('my-variable-text');
    lblmaxlvl.setAttribute('data-textbig','Max level');
    lblmaxlvl.setAttribute('data-textsmall','Level');

    var txtmaxtime = createElement('input');
    txtmaxtime.id = 'maxtime';
    txtmaxtime.type = 'text';
    txtmaxtime.classList.add('my-input-jail');
    txtmaxtime.classList.add('my-margin-left10');
    txtmaxtime.addEventListener('change', (e) => {
        filterTime = parseTime(e.target.value);//e.target.value != '' ? parseTime(e.target.value) : 0;
        saveJailConfig();
        filterJail();
    });
    var lblmaxtime = createElement('label');
    lblmaxtime.for = 'maxtime';
    lblmaxtime.classList.add('my-margin-left10');
    lblmaxtime.classList.add('my-variable-text');
    lblmaxtime.setAttribute('data-textbig','Max time');
    lblmaxtime.setAttribute('data-textsmall','Time');

    var cbquick = createElement('input');
    cbquick.id = 'quick';
    cbquick.type = 'checkbox';
    //cbquick.classList.add('my-input-jail');
    cbquick.classList.add('my-margin-left10');
    cbquick.addEventListener('change', (e) => {
        quick = e.target.checked;//e.target.value != '' ? parseTime(e.target.value) : 0;
        saveJailConfig();
        filterJail();
    });
    var lblquick = createElement('label');
    lblquick.for = 'quick';
    lblquick.classList.add('my-margin-left10');
    lblquick.classList.add('my-variable-text');
    lblquick.setAttribute('data-textbig','Quick bust/bail');
    lblquick.setAttribute('data-textsmall','Q');

    formWrap.appendChild(lblquick);
    formWrap.appendChild(cbquick);

    formWrap.appendChild(lblmaxtime);
    formWrap.appendChild(txtmaxtime);

    formWrap.appendChild(lblmaxlvl);
    formWrap.appendChild(txtmaxlvl);

    widget.header.appendChild(formWrap);

    JailPromise = TornExtStorage.get('Jail');
    JailPromise.then((e) => {
        if(e.Jail){
            filterTime = e.Jail.filterTime;
            filterLvl = e.Jail.filterLvl;
            quick = e.Jail.quick;
        }

        document.getElementById('maxlvl').value = filterLvl;
        document.getElementById('maxtime').value = filterTime;
        document.getElementById('quick').checked = quick;

        filterJail();
    })

    function saveJailConfig(){
        savejail = TornExtStorage.set({'Jail': {'filterTime' : filterTime, 'filterLvl' : filterLvl, 'quick' : quick}});
    }

    /*JAIL FILTER*/
    function filterJail(){
        const prisoners = jail.querySelectorAll('.user-info-list-wrap > li');
    
        for(prisoner of prisoners){
            l = prisoner.querySelector('.level'),
            t = prisoner.querySelector('.time');

            if(l && t) {
                var level = parseInt(l.lastChild.textContent);
                var time = parseTime(t.lastChild.textContent.trim());
                /*
                console.log(l,t);
        
                console.log(l.lastChild.textContent,t.lastChild.textContent, parseTime(t.lastChild.textContent.trim()));
                */
                //prisoner.style.display = 'none'; //for hide

                if(filterTime && time > filterTime || filterLvl && level > filterLvl){
                    prisoner.style.display = 'none';
                }
                else {
                    prisoner.style.removeProperty('display');
                }
            }
        }

        setQuickLink();
    }
    
    function setQuickLink(){
        var linkBust = document.querySelectorAll('a.bust');
        var linkBail = document.querySelectorAll('a.bye');

        var keyworkBust = 'step=breakout';
        var keyworkBail = 'step=buy';
        var keywordPage = 'jailview.php';

        for(bust of linkBust){
            var split = bust.href.split(keyworkBust);
            var newLink = split[0] + keyworkBust + (quick ? '1' : '');
            split = newLink.split(keywordPage);
            newLink = keywordPage + split[1];
            bust.href = newLink;
        }

        for(bail of linkBail){
            var split = bail.href.split(keyworkBail);
            var newLink = split[0] + keyworkBail + (quick ? '1' : '');
            split = newLink.split(keywordPage);
            newLink = keywordPage + split[1];
            bail.href = newLink;
        }
    }

    function parseTime(timeStr) {
        const timeRegEx = /(?:(\d+)h?)?[^\d]*(?:(\d+)m?)?/
        let time = 0;
        const regexTime = timeStr.match(timeRegEx);
        if (regexTime) {
            const [timeStr, hours, minutes] = regexTime;
            hours && (time += 60 * parseInt(hours)), minutes && (time += parseInt(minutes))
        }
        return time;
    }


    // Options for the observer (which mutations to observe)
    var config = { 
        attributes: false,
        characterData: false,
        childList: true,
        subtree: false,
        attributeOldValue: false,
        characterDataOldValue: false };

    // Callback function to execute when mutations are observed
    var callback = function(mutationsList) {
        for(var mutation of mutationsList) {
            if (mutation.type == 'childList') {
                if(mutation.addedNodes.length > 0){
                    for(const node of mutation.addedNodes){
                        if(node.tagName == 'LI'){
                            filterJail();
                            break;//if at least one node is found, all will be checked so no point in loop anymore
                        }
                    }
                }
            }
            else if (mutation.type == 'attributes') {
                //console.log('The ' + mutation.attributeName + ' attribute was modified.');
            }
        }
    };

    // Create an observer instance linked to the callback function
    var observer = new MutationObserver(callback);

    targetNode = jail;

    // Start observing the target node for configured mutations
    observer.observe(targetNode, config);

    // Later, you can stop observing
    //observer.disconnect();
}

})();